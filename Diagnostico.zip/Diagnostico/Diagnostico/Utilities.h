#pragma once
class Utilities
{
public:
	static int GCD(int, int);
	static int reduce(int, int);
};

